// This is just practise
import java.util.Scanner;
public class StudentGradeManagementSystem{
    // This is the main class
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);

        Student student = new Student("Lwando Lusiki", 24, 80.98, 96.33);

        System.out.printf("%.2f", student.calculateFinalMark());
        System.out.println(student.hasPassed());
    }
}