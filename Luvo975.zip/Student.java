public class Student{
    private String name;
    private int age;
    private double mark;
    private double examMark;

    public Student(String name, int age, double mark, double examMark){
        this.name = name;
        this.age = age;
        this.mark = mark;
        this.examMark = examMark;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public int getAge(){
        return age;
    }

    public void setAge(int age){
        this.age = age;
    }

    public String displayDetails(){
        return "Name: "+ ", " +age+" years old";
    }

    public double calculateFinalMark(){
        return ((mark*0.4)/100 + (examMark*0.6)/100)*100;
    }

    public boolean hasPassed(){
        if (calculateFinalMark() >= 50){
            return true;
        }
        else{
            return false;
        }
    }
}